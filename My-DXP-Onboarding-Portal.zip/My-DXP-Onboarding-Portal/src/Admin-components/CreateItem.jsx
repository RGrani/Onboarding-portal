import React from "react";
import Admin from "../Admin";
import "./createitem.css";
const CreateItem=() =>{
    return(
        <div className="format">
            <div>
            <Admin/>
            <h1> create items</h1>
            </div>
        </div>
    );
}
export default CreateItem;