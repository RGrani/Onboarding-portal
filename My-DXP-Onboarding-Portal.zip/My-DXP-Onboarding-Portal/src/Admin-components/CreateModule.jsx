import React from "react";
import Admin from "../Admin";
import "./createitem.css";
const CreateModule=() =>{
    return(
        <div className="format">
           
           <div>
             <Admin/>
            <h1> create Module</h1>
        </div>
      
        </div>
    );
}
export default CreateModule;