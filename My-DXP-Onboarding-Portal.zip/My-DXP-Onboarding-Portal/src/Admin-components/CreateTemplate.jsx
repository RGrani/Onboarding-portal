import React from "react";
import Admin from "../Admin";

const CreateTemplate=() =>{
    return(
        <div className="format">
        <div>
            <Admin/>
            <h1> create Templates</h1>
        </div>
        </div>
    );
}
export default CreateTemplate;