import React from "react";
import './admin.css';
import { useState } from "react";
import { NavLink } from "react-router-dom" ;
import CreateItem from "./Admin-components/CreateItem";

const Admin = () => {
    
const [click, setClick] = useState(false);
      
const handleClick = () => setClick(!click);
    
        return (
          <div className="format">
            <nav className="adminbar">
              <div className="nav-container">
                <h3 className="nav-logo">
                  Admin 
                  {/* <i className="fas fa-code"></i> */}
                </h3>
      
                <ul className={click ? "nav-menu active" : "nav-menu"}>
                  <li className="admin-item">
                    <NavLink
                      exact
                      to="/creatItem"
                      activeClassName="active"
                      className="admin-links"
                      onClick={handleClick}
                    >
                      Create Item
                    </NavLink>
                  </li>
                  <li className="admin-item">
                    <NavLink
                      exact
                      to="/creatTemplate"
                      activeClassName="active"
                      className="admin-links"
                      onClick={handleClick}
                    >
                      Create Template
                    </NavLink>
                  </li>
                  <li className="admin-item">
                    <NavLink
                      exact
                      to="/creatModule"
                      activeClassName="active"
                      className="admin-links"
                      onClick={handleClick}
                    >
                      Create Module
                    </NavLink>
                  </li>
                 
                </ul>
                <div className="nav-icon" onClick={handleClick}>
                  <i className={click ? "fas fa-times" : "fas fa-bars"}></i>
                </div>
              </div>
            </nav>
           
          </div>
      

    );

}

export default Admin;