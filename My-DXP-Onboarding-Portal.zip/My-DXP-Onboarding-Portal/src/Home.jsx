import React from "react";
import { NavLink } from "react-router-dom";
import './Home.css';


 const Home = () =>{
    return( 
        <>
        {/* <Header /> */}
        <div className="home">
            <p>
                Welcome to Onboarding Portal !!
            </p>
            <NavLink to="/login">Let's get started</NavLink>
        </div>
        </>
    );

 }
 export default Home;