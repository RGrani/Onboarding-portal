
import './App.css';

import { Routes, Route } from "react-router-dom"
import Login from './Login';
import Home from './Home';
import Admin from './Admin';
import Header from "./Components/Header";
import Footer from './Components/Footer';
import CreateItem from './Admin-components/CreateItem';
import CreateTemplate from './Admin-components/CreateTemplate';
import CreateModule from './Admin-components/CreateModule';

function App() {
  return (
    <div className="App">
      <Header/>
      <Routes>
        <Route exact path="/"  element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/creatItem" element={<CreateItem />} />
        <Route path="/creatTemplate" element={<CreateTemplate/>} />
        <Route path="/creatModule" element={<CreateModule />} />
        
      
       
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
