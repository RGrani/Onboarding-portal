import { useState } from "react";
import axios from "axios";

function Content() {


    const [uname, setUname] = useState();
    const [password, setPassword] = useState();

    async function submit() {
        try {
            await axios.post("http://localhost:50006/tokenSent",
                {
                    Name: uname,
                    Password: password,
                },
                { headers: { "Content-Type": "application/json", }, });
        }
        catch (error) {
            console.log(error);
            alert("Submit have issue and get failed!!!");
        }
    }
    const handlePassword = (event) => {
        setPassword(event.target.value);
        console.log(password);
    }
    const handleInput = (event) => {
        setUname(event.target.value);
        console.log(uname);
    }
    return (


        <div className="App">

            <form>
                <div className="input-container">
                    <label>Employee ID : </label>
                    <input type="text" name="eid" placeholder="Enter your Employee ID" onChange={handleInput} required />

                </div>
                <div className="input-container">
                    <label>Password :</label>
                    <input type="password" name="pass" onChange={handlePassword} required />

                </div>
                <div className="button-container">
                    <button type="submit" name="submit" onClick={submit}>SUBMIT</button>
                </div>
            </form>
        </div>


    );
}

export default Content;
