
import './App.css';
import Content from "./Content";
import Button from "./Button"
import { Routes, Route } from "react-router-dom"

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Button />} />
        <Route path="/content" element={<Content />} />
      </Routes>
    </div>
  );
}

export default App;
