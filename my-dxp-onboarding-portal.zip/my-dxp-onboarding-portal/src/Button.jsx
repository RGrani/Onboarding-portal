
import { useNavigate } from "react-router-dom";
import './button.css';
function Button() {

    const navigate = useNavigate();

    const handleChange = () => {
        navigate('/content');
    }

    return (
        <div className="App">
            <button className="button" onClick={handleChange}><span>Onboarding Portal</span></button>
        </div>
    );
}

export default Button;
